a=input('Enter the string ')
print(a[::-1])
