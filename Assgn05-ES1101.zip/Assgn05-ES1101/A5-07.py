for i in range(8,501):
    if i%7==0:
        if i%11==0:
            print(i)
